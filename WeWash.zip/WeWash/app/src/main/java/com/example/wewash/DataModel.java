package com.example.wewash;

import android.widget.Button;

public class DataModel {
    String name,address;
    int number;
    public DataModel(String name, String address,int number) {
        this.name = name;
        this.address = address;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getNumber() {
        return String.valueOf(number);
    }
}
