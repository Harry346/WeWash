package com.example.wewash;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class OrderActivity extends AppCompatActivity {
    Button btnDatePicker, btnTimePicker;
    private Toolbar toolbar;
    TextView txtDate, txtTime;
    private int mYear, mMonth, mDay, mHour, mMinute;
    private CheckBox steam, washndfold, washndpress, drycleaning;
    private Button ordernow;
    private PickupDatabase pickupDatabase;
    private EditText address;
    public final String steampress = "Steam Press";
    public final String washfold = "Wash & Fold";
    public final String washpress = "Wash & Press";
    public final String dryclean = "Dry Cleaning";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        btnDatePicker = (Button) findViewById(R.id.btn_date);
        btnTimePicker = (Button) findViewById(R.id.btn_time);
        txtDate = (TextView) findViewById(R.id.in_date);
        txtTime = (TextView) findViewById(R.id.in_time);
        steam = findViewById(R.id.steam);
        washndfold = findViewById(R.id.washndfold);
        washndpress = findViewById(R.id.washndpress);
        drycleaning = findViewById(R.id.drycleaning);
        ordernow = findViewById(R.id.ordernow);
        address = findViewById(R.id.address);
        toolbar=findViewById(R.id.ordertoolbar);
        toolbar.setTitle("Order");
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);


        pickupDatabase = new PickupDatabase(this, PickupDatabase.DATABASE_NAME, null, 1);


        steam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                steam.setChecked(true);
                washndpress.setChecked(false);
                washndfold.setChecked(false);
                drycleaning.setChecked(false);

            }
        });
        washndfold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                steam.setChecked(false);
                washndpress.setChecked(false);
                washndfold.setChecked(true);
                drycleaning.setChecked(false);

            }
        });
        washndpress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                steam.setChecked(false);
                washndpress.setChecked(true);
                washndfold.setChecked(false);
                drycleaning.setChecked(false);

            }
        });
        drycleaning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                steam.setChecked(false);
                washndpress.setChecked(false);
                washndfold.setChecked(false);
                drycleaning.setChecked(true);

            }
        });

        btnDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(OrderActivity.this, new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.show();
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis() + 604800000);

            }
        });
        btnTimePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(OrderActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                txtTime.setText(hourOfDay + ":" + minute);
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();
            }
        });

        ordernow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                placeorder();
            }


            private void placeorder() {
                String date = txtDate.getText().toString().trim();
                String time = txtTime.getText().toString().trim();
                String addres = address.getText().toString().trim();

                if (TextUtils.isEmpty(date)) {
                    Toast.makeText(OrderActivity.this, "Please select Date", Toast.LENGTH_SHORT).show();

                } else if (TextUtils.isEmpty(time)) {
                    Toast.makeText(OrderActivity.this, "Please select Time", Toast.LENGTH_SHORT).show();

                } else if (TextUtils.isEmpty(addres)) {

                    Toast.makeText(OrderActivity.this, "Please enter Address", Toast.LENGTH_SHORT).show();
                } else if (steam.isChecked()) {

                    boolean status = pickupDatabase.pickupdata(steampress, date, time, addres);
                    if (status == true) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(OrderActivity.this);
                        builder.setTitle("Thank You");
                        builder.setMessage("Your order has been placed");
                        builder.setCancelable(false);

                        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                                finish();
                                startActivity(intent);
                            }
                        });
                        builder.create();
                        builder.show();
                    }

                } else if (washndpress.isChecked()) {

                    boolean status = pickupDatabase.pickupdata(washpress, date, time, addres);
                    if (status == true) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(OrderActivity.this);
                        builder.setTitle("Thank You");
                        builder.setMessage("Your order has been placed");
                        builder.setCancelable(false);

                        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                                finish();
                                startActivity(intent);
                            }
                        });
                        builder.create();
                        builder.show();
                    }

                } else if (washndfold.isChecked()) {

                    boolean status = pickupDatabase.pickupdata(washfold, date, time, addres);
                    if (status == true) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(OrderActivity.this);
                        builder.setTitle("Thank You");
                        builder.setMessage("Your order has been placed");
                        builder.setCancelable(false);

                        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                                finish();
                                startActivity(intent);
                            }
                        });
                        builder.create();
                        builder.show();
                    }

                } else if (drycleaning.isChecked()) {

                    boolean status = pickupDatabase.pickupdata(dryclean, date, time, addres);
                    if (status == true) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(OrderActivity.this);
                        builder.setTitle("Thank You");
                        builder.setMessage("Your order has been placed");
                        builder.setCancelable(false);

                        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                                finish();
                                startActivity(intent);
                            }
                        });
                        builder.create();
                        builder.show();
                    }
                }

            }
        });


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case android.R.id.home:
                Intent intent = new Intent(OrderActivity.this,HomeActivity.class);
                startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
