package com.example.wewash;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Myprofile extends AppCompatActivity {
    private Toolbar toolbar;
    private EditText profilename,profilenumber,profileemail,profilepasssword;
    AlertDialog dialog_username, dialog_phone;
    EditText edittext_user, editText_phone;
    private RadioButton profilemale,profilefemale;
    ImageView profileimage;
    public static final int REQUEST_CODE_FOR_CAMERA=1002;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myprofile);
        profilename = findViewById(R.id.profilename);
        profileemail = findViewById(R.id.profileemail);
        profilenumber = findViewById(R.id.profilenumber);
        profilepasssword = findViewById(R.id.profilepassword);
        profilemale = findViewById(R.id.malebutton);
        profilefemale = findViewById(R.id.femalebutton);
        profileimage = findViewById(R.id.profileimage);
        toolbar = findViewById(R.id.profiletoolbar);
        toolbar.setTitle("My Profile");
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        profilefemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profilefemale.setChecked(true);
                profilemale.setChecked(false);
            }
        });
        profilemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profilemale.setChecked(true);
                profilefemale.setChecked(false);
            }
        });

        if (sharedprofile.getBitmapimage() != null) {
            profileimage.setImageBitmap(sharedprofile.getBitmapimage());
        } else {
            profileimage.setImageResource(R.mipmap.ic_launcher);
        }
        profileimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Myprofile.this);
                builder.setTitle("Choose from one among this..");
                builder.setItems(new CharSequence[]{"Camera"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                if (ContextCompat.checkSelfPermission(Myprofile.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                    getImageFromCamera();
                                } else {
                                    ActivityCompat.requestPermissions(Myprofile.this, new String[]{Manifest.permission.CAMERA}, REQUEST_CODE_FOR_CAMERA);

                                }

                                break;
                        }
                    }
                });
                builder.create().show();
            }
        });
        profileemail = findViewById(R.id.profileemail);
        profilenumber = findViewById(R.id.profilenumber);

        profileemail.setText(sharedprofile.getEmail());
        profilenumber.setText(profilenumber.getText() + "" + sharedprofile.getNumber());
        profilename.setText(sharedprofile.getName());

        dialog_username = new AlertDialog.Builder(Myprofile.this).create();
        dialog_username.setTitle("Update Your userName");
        edittext_user = new EditText(Myprofile.this);
        dialog_username.setView(edittext_user);

        dialog_phone = new AlertDialog.Builder(Myprofile.this).create();
        dialog_phone.setTitle("Update Your Phone Number");
        editText_phone = new EditText(Myprofile.this);
        dialog_phone.setView(editText_phone);

        dialog_username.setButton(DialogInterface.BUTTON_POSITIVE, "Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                profilename.setText(edittext_user.getText().toString().trim());
                MyDatabase myDatabase= new MyDatabase(getApplicationContext(),MyDatabase.DATABASE_NAME,null,1);
                SQLiteDatabase sqLiteDatabase = myDatabase.getWritableDatabase();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MyDatabase.COL_1, edittext_user.getText().toString().trim());
                int i = sqLiteDatabase.update(MyDatabase.TABLE_NAME, contentValues, MyDatabase.COL_5 + "=?", new String[]{sharedprofile.getId().toString()});
                if (i <= 0) {
                    Toast.makeText(Myprofile.this, "Unable to update ", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Myprofile.this, "Updated Successfully", Toast.LENGTH_SHORT).show();
                    sharedprofile.setName(edittext_user.getText().toString().trim());
                }
                sqLiteDatabase.close();

            }
        });
        profilename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext_user.setText(profilename.getText());
                dialog_username.show();
            }
        });

        profilenumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText_phone.setText(sharedprofile.getNumber());
                dialog_phone.show();
            }
        });
        dialog_phone.setButton(DialogInterface.BUTTON_POSITIVE, "Update phone", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                profilenumber.setText(editText_phone.getText().toString().trim());
                MyDatabase myDatabase = new MyDatabase(Myprofile.this,MyDatabase.DATABASE_NAME,null,1);
                SQLiteDatabase sqLiteDatabase = myDatabase.getWritableDatabase();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MyDatabase.COL_2, editText_phone.getText().toString().trim());
                sqLiteDatabase.update(MyDatabase.TABLE_NAME, contentValues, MyDatabase.COL_4 + "=?", new String[]{sharedprofile.getId().toString()});
                sharedprofile.setNumber(editText_phone.getText().toString().trim());
                sqLiteDatabase.close();
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_CODE_FOR_CAMERA & resultCode == RESULT_OK) {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            profileimage.setImageBitmap(bitmap);
            sharedprofile.setBitmapimage(bitmap);
            saveIndbBitMap();
        }
    }

    public void getImageFromCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CODE_FOR_CAMERA);
    }

    public void saveIndbBitMap() {
        File packagedir = Myprofile.this.getFilesDir();
        String modifiedemail = packagedir + "/" + sharedprofile.getEmail().substring(0, sharedprofile.getEmail().indexOf("@"));
        File lee = new File(modifiedemail);
        String imagename = "profilepic";
        File list_of_files[] = lee.listFiles();
        for (File filenames : list_of_files) {
            String actualfilename = String.valueOf(filenames);
            if (imagename.contentEquals(actualfilename)) {
                filenames.delete();
                Toast.makeText(Myprofile.this, "Deleted", Toast.LENGTH_SHORT).show();
            }
        }
        File file = new File(modifiedemail, imagename);
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(file);
            sharedprofile.getBitmapimage().compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode==REQUEST_CODE_FOR_CAMERA && grantResults[0]==PackageManager.PERMISSION_GRANTED)
        {
            getImageFromCamera();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Do not have permission please \n Go to Settings Application and change it",Toast.LENGTH_SHORT).show();
        }
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case android.R.id.home:
                Intent intent = new Intent(Myprofile.this,HomeActivity.class);
                startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
