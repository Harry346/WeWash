package com.example.wewash;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText log_phone, log_password;
    private Button log_btn;
    private MyDatabase myDatabase;
    private TextView titype;
    int setPtype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        log_phone = findViewById(R.id.log_phn);
        log_password = findViewById(R.id.log_password);
        log_btn = findViewById(R.id.log_btn);
        titype=findViewById(R.id.titype);
        myDatabase = new MyDatabase(this, MyDatabase.DATABASE_NAME, null, 1);
        log_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginUser();
            }
        });

        setPtype=1;
        titype.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setPtype==1){
                    setPtype=0;
                    log_password.setTransformationMethod(null);
                    if (log_password.getText().length()>0)
                        log_password.setSelection(log_password.getText().length());
                    titype.setBackgroundResource(R.drawable.redeye);

                }

                else{
                    setPtype=1;
                    log_password.setTransformationMethod(new PasswordTransformationMethod());
                    if (log_password.getText().length()>0)
                        log_password.setSelection(log_password.getText().length());
                    titype.setBackgroundResource(R.drawable.eye);
                }

            }
        });



    }

    private void LoginUser() {
        String phonenumber = log_phone.getText().toString().trim();
        String password = log_password.getText().toString().trim();

        if (TextUtils.isEmpty(phonenumber)) {
            Toast.makeText(this, "Please enter your phone number", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter the password", Toast.LENGTH_SHORT).show();
        } else {
            Cursor cursor = myDatabase.getData(log_phone.getText().toString().trim());
            if (cursor.getCount() == 0)
                Toast.makeText(this, "Account Doesn't exists", Toast.LENGTH_LONG).show();
            else if (cursor.moveToNext()) {
                if (cursor.getString(3).equals(log_password.getText().toString().trim())) {
                    Toast.makeText(this, "Logged in", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    startActivity(intent);
                } else Toast.makeText(this, "Password is incorrect", Toast.LENGTH_LONG).show();
            }
        }

    }
}