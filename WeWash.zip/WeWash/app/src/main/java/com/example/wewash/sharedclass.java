package com.example.wewash;

public class sharedclass {

    public static String service,date,time,address;

    public static String getService() {
        return service;
    }

    public static void setService(String service) {
        sharedclass.service = service;
    }

    public static String getDate() {
        return date;
    }

    public static void setDate(String date) {
        sharedclass.date = date;
    }

    public static String getTime() {
        return time;
    }

    public static void setTime(String time) {
        sharedclass.time = time;
    }

    public static String getAddress() {
        return address;
    }

    public static void setAddress(String address) {
        sharedclass.address = address;
    }
}
