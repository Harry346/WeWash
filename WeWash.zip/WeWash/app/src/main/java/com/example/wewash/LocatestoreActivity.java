package com.example.wewash;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class LocatestoreActivity extends AppCompatActivity {
    private Button locate1,locate2,locate3;
    private Button call1,call2,call3;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locatestore);
        locate1=findViewById(R.id.locatetony);
        locate2=findViewById(R.id.locateroop);
        locate3=findViewById(R.id.locatehira);
        call1=findViewById(R.id.calltony);
        call2=findViewById(R.id.callroop);
        call3=findViewById(R.id.callhira);
        toolbar=findViewById(R.id.locatetoolbar);
        toolbar.setTitle("Locate Stores");
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);


        locate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:<31.301724>,<75.578100>?q=<31.301724>,<75.578100>(Tony Dry Cleanings)"));
                startActivity(intent);
            }
        });
        locate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:<31.286977>,<75.647033>?q=<31.286977>,<75.647033>(Label+Name)"));
                startActivity(intent);
            }
        });
        locate3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:<31.287161>,<75.644392>?q=<31.287161>,<75.644392>(Label+Name)"));
                startActivity(intent);
            }
        });
        call1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:9888454523"));
                startActivity(intent);
            }
        });
        call2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:8054025669"));
                startActivity(intent);
            }
        });
        call3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:01812661043"));
                startActivity(intent);
            }
        });


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case android.R.id.home:
                Intent intent = new Intent(LocatestoreActivity.this,HomeActivity.class);
                startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
