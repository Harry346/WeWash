package com.example.wewash;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

public class MyordersActivity extends AppCompatActivity {

    private TextView service,date,time,address;
    private Toolbar toolbar;

    private PickupDatabase pickupDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myorders);
        toolbar=findViewById(R.id.myordertoolbar);
        toolbar.setTitle("My Orders");
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        service=findViewById(R.id.service);
        date=findViewById(R.id.date);
        time=findViewById(R.id.time);
        address=findViewById(R.id.address);


        service.setText(sharedclass.getService());
        date.setText(sharedclass.getDate());
        time.setText(sharedclass.getTime());
        address.setText(sharedclass.getAddress());

       pickupDatabase = new PickupDatabase(this,PickupDatabase.DATABASE_NAME,null,1);

    }
}
