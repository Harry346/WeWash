package com.example.wewash;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class PickupDatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Pickup.db";
    public static final String TABLE_NAME = "pickup";
    public static final String COL_1 = "SERVICE";
    public static final String COL_2 = "DATE";
    public static final String COL_3 = "TIME";
    public static final String COL_4 = "ADDRESS";

    public PickupDatabase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + "(SERVICE TEXT,DATE TEXT,TIME TEXT,ADDRESS TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean pickupdata(String service, String date, String time, String address) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, service);
        contentValues.put(COL_2, date);
        contentValues.put(COL_3, time);
        contentValues.put(COL_4, address);
        long result = sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
        if (result == -1) return false;
        else return true;
    }

    public Cursor getorder(String name) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from MyDatabase where name='" + name + "'", null);
        if (cursor.moveToFirst()) {
            do {
                String s1 = cursor.getString(cursor.getColumnIndex("service"));
                String s2 = cursor.getString(cursor.getColumnIndex("date"));
                String s3 = cursor.getString(cursor.getColumnIndex("time"));
                String s4 = cursor.getString(cursor.getColumnIndex("address"));
            } while (cursor.moveToNext());
        }
        return cursor;

    }
}
