package com.example.wewash;

import android.content.Intent;
import android.graphics.Bitmap;

public class sharedprofile {
    public static String name,number,email,password;
    public static Bitmap bitmapimage;
    public static Integer id;

    public static Integer getId() {
        return id;
    }

    public static void setId(Integer id) {
        sharedprofile.id = id;
    }

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        sharedprofile.name = name;
    }

    public static String getNumber() {
        return number;
    }

    public static void setNumber(String number) {
        sharedprofile.number = number;
    }

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        sharedprofile.email = email;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        sharedprofile.password = password;
    }

    public static Bitmap getBitmapimage() {
        return bitmapimage;
    }

    public static void setBitmapimage(Bitmap bitmapimage) {
        sharedprofile.bitmapimage = bitmapimage;
    }
}
