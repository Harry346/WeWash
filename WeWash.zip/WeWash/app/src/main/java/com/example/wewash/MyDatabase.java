package com.example.wewash;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "WeWash.db";
    public static final String TABLE_NAME = "WASH";
    public static final String TABLE_NAME2 = "pickup";
    public static final String COL_1 = "NAME";
    public static final String COL_2 = "PHONENUMBER";
    public static final String COL_3 = "EMAIL";
    public static final String COL_4 = "PASSWORD";
    public static final String COL_5= "ID";
    public MyDatabase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " +TABLE_NAME+"(NAME TEXT,PHONENUMBER INTEGER,EMAIL TEXT,PASSWORD TEXT, ID INTEGER PRIMARY KEY AUTOINCREMENT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertData(String name,String phonenumber,String email,String password) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, name);
        contentValues.put(COL_2, phonenumber);
        contentValues.put(COL_3, email);
        contentValues.put(COL_4, password);
        long result = sqLiteDatabase.insert(TABLE_NAME,null,contentValues);
        if(result == -1) return false;
        else  return true;
    }
    public Cursor getData(String phonenumber)
    {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from "+TABLE_NAME+" where "+COL_2+" = ?",new String[]{phonenumber});
        return cursor;
    }
    public Cursor getDatae(String email)
    {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor1 = sqLiteDatabase.rawQuery("Select * from "+TABLE_NAME+" where "+COL_3+" = ?",new String[]{email});
        return cursor1;
    }

    public Cursor getAllData()
    {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from "+TABLE_NAME,null);
        return cursor;
    }
}
