package com.example.wewash;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity{
    private Toolbar toolbar;
    private DrawerLayout drawerlayout;
    private NavigationView navigationView;
    private Button orderpickup,contactus,locatestores;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        toolbar=findViewById(R.id.toolbar);
        drawerlayout=findViewById(R.id.drawerlayout);
        navigationView=findViewById(R.id.navigationview);
        orderpickup=findViewById(R.id.order_pickup);
        contactus=findViewById(R.id.contact_us);
        locatestores=findViewById(R.id.locate_store);
        toolbar.setTitle("WeWash");
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.navmenu);






        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()){
                    case R.id.homeid:
                        Toast.makeText(HomeActivity.this, "Home", Toast.LENGTH_SHORT).show();
                        menuItem.setCheckable(false);
                        drawerlayout.closeDrawers();
                        return true;
                    case R.id.orderpickup:
                        Toast.makeText(HomeActivity.this, "Order Pickup", Toast.LENGTH_SHORT).show();
                        menuItem.setCheckable(false);
                        drawerlayout.closeDrawers();
                        Intent intent = new Intent(HomeActivity.this,OrderActivity.class);
                        startActivity(intent);
                        return true;
                    case R.id.locatestore:
                        Toast.makeText(HomeActivity.this, "Locate Stores", Toast.LENGTH_SHORT).show();
                        menuItem.setCheckable(false);
                        drawerlayout.closeDrawers();
                        Intent intent1=new Intent(HomeActivity.this,LocatestoreActivity.class);
                        startActivity(intent1);
                        return true;
                    case R.id.share:
                        Toast.makeText(HomeActivity.this, "Share", Toast.LENGTH_SHORT).show();
                        menuItem.setCheckable(false);
                        drawerlayout.closeDrawers();
                        Intent intent2 = new Intent(Intent.ACTION_SEND);
                        intent2.setType("text/plain");
                        intent2.putExtra(Intent.EXTRA_TEXT,"Hey I found an interesting app. I recommend" +
                                " you to download and use it http://www.tinyurl.com/wellwash");
                        startActivity(Intent.createChooser(intent2,"Share via"));
                        return true;
                    case R.id.pricecalc:
                        Toast.makeText(HomeActivity.this, "Price Calculator", Toast.LENGTH_SHORT).show();
                        menuItem.setCheckable(false);
                        drawerlayout.closeDrawers();
                        Intent intent5 = new Intent(HomeActivity.this,Pricecalculator.class);
                        startActivity(intent5);
                        return true;
                    case R.id.aboutus:
                        Toast.makeText(HomeActivity.this, "About Us", Toast.LENGTH_SHORT).show();
                        menuItem.setCheckable(false);
                        drawerlayout.closeDrawers();
                        return true;
                    case R.id.contactus:
                        Toast.makeText(HomeActivity.this, "Contact Us", Toast.LENGTH_SHORT).show();
                        menuItem.setCheckable(false);
                        drawerlayout.closeDrawers();
                        Intent i = new Intent(HomeActivity.this,ContactusActivity.class);
                        startActivity(i);
                        return true;
                    case R.id.logout:
                        menuItem.setCheckable(false);
                        drawerlayout.closeDrawers();
                        logout();
                        return true;


                }
                return false;
            }
        });

        orderpickup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,OrderActivity.class);
                startActivity(intent);
            }
        });
        locatestores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,LocatestoreActivity.class);
                startActivity(intent);
            }
        });
        contactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,ContactusActivity.class);
                startActivity(intent);
            }
        });




    }

    private void logout() {
        Toast.makeText(HomeActivity.this, "Logout", Toast.LENGTH_SHORT).show();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Log Out");
        builder.setMessage("Do you want to Logout ?");
        builder.setIcon(R.drawable.logout);
        builder.setCancelable(false);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                finish();
                startActivity(intent);
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.create();
        builder.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case android.R.id.home:
                drawerlayout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed () {
        // super.onBackPressed();
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Exit Dialogue");
            builder.setMessage("Do you want to exit ?");
            builder.setIcon(R.drawable.logout);
            builder.setCancelable(false);

            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent=new Intent(HomeActivity.this,LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });

            builder.create();
            builder.show();
        }

    }
