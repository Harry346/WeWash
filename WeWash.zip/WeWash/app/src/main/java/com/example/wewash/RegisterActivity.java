package com.example.wewash;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class RegisterActivity extends AppCompatActivity {
    private Button createbtn;
    private EditText regname,regphonenumber,regemail,regpassword,regcpassword;
    private MyDatabase myDatabase;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        createbtn = findViewById(R.id.createbtn);
        regname = findViewById(R.id.reg_name);
        regphonenumber = findViewById(R.id.reg_phn);
        regemail=findViewById(R.id.reg_email);
        regpassword = findViewById(R.id.reg_password);
        regcpassword = findViewById(R.id.reg_cpassword);
        myDatabase = new MyDatabase(this,MyDatabase.DATABASE_NAME,null,1);


        createbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createaccount();
            }
        });
    }

    private void createaccount() {

        String name= regname.getText().toString().trim();
        String phonenumber=regphonenumber.getText().toString().trim();
        String password=regpassword.getText().toString().trim();
        String cpassword=regcpassword.getText().toString().trim();
        String email=regemail.getText().toString().trim();

        if (TextUtils.isEmpty(name)){
            Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(phonenumber)){
            Toast.makeText(this, "Please enter your phone number", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(password)){
            Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(cpassword)){
            Toast.makeText(this, "Please confirm your password", Toast.LENGTH_SHORT).show();
        }
        else if(myDatabase.getData(phonenumber).moveToFirst()) {
            Toast.makeText(getApplicationContext(), "Phone Number already in use", Toast.LENGTH_SHORT).show();
        }
        else if(myDatabase.getDatae(email).moveToFirst()) {
            Toast.makeText(getApplicationContext(), "Email already in use", Toast.LENGTH_SHORT).show();
        }
        else if (!regpassword.getText().toString().trim().equals(regcpassword.getText().toString().trim())){
            Toast.makeText(this, "Passwords doesn't match", Toast.LENGTH_SHORT).show();
        }
        else
        {
            String s1,s2,s3,s4;
            s1=name;
            s2=phonenumber;
            s3=email;
            s4=password;
            boolean status=myDatabase.insertData(s1,s2,s3,s4);

            if (status){
                Toast.makeText(this, "Your Account has been created", Toast.LENGTH_SHORT).show();
                createFileandFolder(s3);
                Intent intent=new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "Network Error : Please Try Again Later", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(RegisterActivity.this,MainActivity.class);
                startActivity(intent);
            }


        }

    }
    private void createFileandFolder(String email) {
        {
            int count=email.indexOf("@");
            String modifiedemail=email.substring(0,count);
            File packagedir=getApplicationContext().getFilesDir();
            File userfile=new File(packagedir,modifiedemail);
            userfile.mkdirs();
        }
    }

}
